/* ==========================================================================
   PORTAFOLIO PERSONAL - ZOE MILLER
   Lógica JavaScript (main.js)
   Inspirado en el tutorial de Cryptical Coder
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {

    /* ==================== 1. MENÚ DE NAVEGACIÓN MÓVIL ==================== */
    const navMenu = document.getElementById('nav-menu');
    const navToggle = document.getElementById('nav-toggle');
    const navLinks = document.querySelectorAll('.nav__link');

    // Mostrar / Ocultar menú en móviles
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', (e) => {
            e.stopPropagation();
            navMenu.classList.toggle('show-menu');
            navToggle.classList.toggle('active-toggle');
        });
    }

    // Cerrar menú al hacer clic en un enlace de navegación
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (navMenu.classList.contains('show-menu')) {
                navMenu.classList.remove('show-menu');
                if (navToggle) navToggle.classList.remove('active-toggle');
            }
        });
    });

    // Cerrar menú al hacer clic fuera de él
    document.addEventListener('click', (e) => {
        if (navMenu && navMenu.classList.contains('show-menu')) {
            if (!navMenu.contains(e.target) && !navToggle.contains(e.target)) {
                navMenu.classList.remove('show-menu');
                if (navToggle) navToggle.classList.remove('active-toggle');
            }
        }
    });

    /* ==================== 2. SOMBRA & BLUR DEL HEADER AL HACER SCROLL ==================== */
    const header = document.getElementById('header');

    function scrollHeader() {
        if (!header) return;
        if (window.scrollY >= 50) {
            header.classList.add('scroll-header');
        } else {
            header.classList.remove('scroll-header');
        }
    }
    window.addEventListener('scroll', scrollHeader);

    /* ==================== 3. SCROLLSPY (ENLACE ACTIVO EN NAVEGACIÓN) ==================== */
    const sections = document.querySelectorAll('section[id]');

    function scrollActive() {
        const scrollY = window.pageYOffset;

        sections.forEach(current => {
            const sectionHeight = current.offsetHeight;
            const sectionTop = current.offsetTop - 100;
            const sectionId = current.getAttribute('id');
            const navLink = document.querySelector(`.nav__menu a[href*="${sectionId}"]`);

            if (navLink) {
                if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
                    navLink.classList.add('active-link');
                } else {
                    navLink.classList.remove('active-link');
                }
            }
        });
    }
    window.addEventListener('scroll', scrollActive);

    /* ==================== 4. CAMBIADOR DE ESTILO / COLOR (STYLE SWITCHER) ==================== */
    const styleSwitcher = document.getElementById('style-switcher');
    const switcherToggle = document.getElementById('switcher-toggle');
    const switcherClose = document.getElementById('switcher-close');
    const switcherColors = document.querySelectorAll('.style__switcher-color');
    const lightThemeRadio = document.getElementById('light-theme');
    const darkThemeRadio = document.getElementById('dark-theme');

    // Abrir / Cerrar panel
    if (switcherToggle && styleSwitcher) {
        switcherToggle.addEventListener('click', (e) => {
            e.stopPropagation();
            styleSwitcher.classList.toggle('open');
        });
    }

    if (switcherClose && styleSwitcher) {
        switcherClose.addEventListener('click', () => {
            styleSwitcher.classList.remove('open');
        });
    }

    // Cerrar panel de estilo al hacer scroll o clic fuera
    window.addEventListener('scroll', () => {
        if (styleSwitcher && styleSwitcher.classList.contains('open')) {
            styleSwitcher.classList.remove('open');
        }
    });

    document.addEventListener('click', (e) => {
        if (styleSwitcher && styleSwitcher.classList.contains('open')) {
            if (!styleSwitcher.contains(e.target) && !switcherToggle.contains(e.target)) {
                styleSwitcher.classList.remove('open');
            }
        }
    });

    // Cambio dinámico de tono de color (Hue)
    function setAccentColor(hue) {
        document.documentElement.style.setProperty('--hue', hue);
        localStorage.setItem('selected-hue', hue);

        switcherColors.forEach(color => {
            if (color.getAttribute('data-hue') === hue) {
                color.classList.add('active-color');
            } else {
                color.classList.remove('active-color');
            }
        });
    }

    switcherColors.forEach(color => {
        color.addEventListener('click', () => {
            const hue = color.getAttribute('data-hue');
            setAccentColor(hue);
        });
    });

    // Cambio entre modo Claro y Oscuro
    function setTheme(theme) {
        if (theme === 'dark') {
            document.body.classList.add('dark-theme');
            if (darkThemeRadio) darkThemeRadio.checked = true;
            localStorage.setItem('selected-theme', 'dark');
        } else {
            document.body.classList.remove('dark-theme');
            if (lightThemeRadio) lightThemeRadio.checked = true;
            localStorage.setItem('selected-theme', 'light');
        }
    }

    if (lightThemeRadio && darkThemeRadio) {
        lightThemeRadio.addEventListener('change', () => setTheme('light'));
        darkThemeRadio.addEventListener('change', () => setTheme('dark'));
    }

    // Restaurar preferencias guardadas en LocalStorage
    const savedHue = localStorage.getItem('selected-hue');
    if (savedHue) {
        setAccentColor(savedHue);
    }

    const savedTheme = localStorage.getItem('selected-theme');
    if (savedTheme) {
        setTheme(savedTheme);
    } else {
        // Por defecto: Tema Oscuro
        setTheme('dark');
    }

    /* ==================== 5. SWIPER SLIDERS (SERVICIOS & TESTIMONIOS) ==================== */
    // Servicios Swiper
    if (typeof Swiper !== 'undefined' && document.querySelector('.services__container')) {
        new Swiper('.services__container', {
            slidesPerView: 1,
            spaceBetween: 24,
            loop: true,
            grabCursor: true,
            autoplay: {
                delay: 4500,
                disableOnInteraction: false,
            },
            pagination: {
                el: '.services__container .swiper-pagination',
                clickable: true,
            },
            breakpoints: {
                640: {
                    slidesPerView: 2,
                    spaceBetween: 24,
                },
                992: {
                    slidesPerView: 3,
                    spaceBetween: 28,
                },
            },
        });
    }

    // Testimonios Swiper
    if (typeof Swiper !== 'undefined' && document.querySelector('.testimonials__container')) {
        new Swiper('.testimonials__container', {
            slidesPerView: 1,
            spaceBetween: 24,
            loop: true,
            grabCursor: true,
            autoplay: {
                delay: 5000,
                disableOnInteraction: false,
            },
            pagination: {
                el: '.testimonials__container .swiper-pagination',
                clickable: true,
            },
            breakpoints: {
                768: {
                    slidesPerView: 2,
                    spaceBetween: 24,
                },
            },
        });
    }

    /* ==================== 6. FILTRO DE PROYECTOS (MIXITUP / FALLBACK) ==================== */
    const workContainer = document.querySelector('.work__container');
    const filterButtons = document.querySelectorAll('.work__item');

    if (typeof mixitup !== 'undefined' && workContainer) {
        const mixer = mixitup(workContainer, {
            selectors: {
                target: '.work__card',
            },
            animation: {
                duration: 400,
            },
        });

        // Alternar clase activa en botones de filtro
        filterButtons.forEach(btn => {
            btn.addEventListener('click', function () {
                filterButtons.forEach(item => item.classList.remove('active-work'));
                this.classList.add('active-work');
            });
        });
    } else if (workContainer) {
        // Fallback nativo de JavaScript si MixItUp no está disponible
        filterButtons.forEach(btn => {
            btn.addEventListener('click', function () {
                filterButtons.forEach(item => item.classList.remove('active-work'));
                this.classList.add('active-work');

                const filter = this.getAttribute('data-filter');
                const cards = document.querySelectorAll('.work__card');

                cards.forEach(card => {
                    if (filter === 'all' || card.classList.contains(filter.replace('.', ''))) {
                        card.style.display = 'flex';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    }

    /* ==================== 7. ACORDEÓN DE RESUMEN / EXPERIENCIA ==================== */
    const resumeHeaders = document.querySelectorAll('.resume__header');

    resumeHeaders.forEach(headerItem => {
        headerItem.addEventListener('click', () => {
            const parentItem = headerItem.parentElement;
            const icon = headerItem.querySelector('.resume__icon i');
            const isOpen = parentItem.classList.contains('accordion-open');

            if (isOpen) {
                parentItem.classList.remove('accordion-open');
                if (icon) {
                    icon.classList.remove('ri-subtract-line');
                    icon.classList.add('ri-add-line');
                }
            } else {
                parentItem.classList.add('accordion-open');
                if (icon) {
                    icon.classList.remove('ri-add-line');
                    icon.classList.add('ri-subtract-line');
                }
            }
        });
    });

    /* ==================== 8. FORMULARIO DE CONTACTO ==================== */
    const contactForm = document.getElementById('contact-form');
    const contactMessage = document.getElementById('message');
    const contactBtn = document.getElementById('contact-btn');

    if (contactForm && contactMessage) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const name = document.getElementById('contact-name').value.trim();
            const email = document.getElementById('contact-email').value.trim();
            const message = document.getElementById('contact-message').value.trim();

            if (!name || !email || !message) {
                contactMessage.textContent = '❌ Por favor completa todos los campos requeridos.';
                contactMessage.className = 'contact__status-message error';
                return;
            }

            // Estado de envío
            if (contactBtn) {
                contactBtn.disabled = true;
                contactBtn.innerHTML = '<i class="ri-loader-4-line"></i> Enviando...';
            }

            // Simulación de envío exitoso (o integración con EmailJS)
            setTimeout(() => {
                contactMessage.textContent = '✅ ¡Mensaje enviado con éxito! Te responderé lo más pronto posible.';
                contactMessage.className = 'contact__status-message success';
                contactForm.reset();

                if (contactBtn) {
                    contactBtn.disabled = false;
                    contactBtn.innerHTML = '<i class="ri-send-plane-fill"></i> Enviar Mensaje';
                }

                // Limpiar mensaje tras 6 segundos
                setTimeout(() => {
                    contactMessage.textContent = '';
                    contactMessage.className = 'contact__status-message';
                }, 6000);
            }, 1200);
        });
    }

    /* ==================== 9. BOTÓN SCROLL-TO-TOP ==================== */
    const scrollUp = document.getElementById('scroll-up');

    function checkScrollUp() {
        if (!scrollUp) return;
        if (window.scrollY >= 350) {
            scrollUp.classList.add('show-scroll');
        } else {
            scrollUp.classList.remove('show-scroll');
        }
    }
    window.addEventListener('scroll', checkScrollUp);

    /* ==================== 10. AÑO DINÁMICO EN FOOTER ==================== */
    const currentYearSpan = document.getElementById('current-year');
    if (currentYearSpan) {
        currentYearSpan.textContent = new Date().getFullYear();
    }
});

